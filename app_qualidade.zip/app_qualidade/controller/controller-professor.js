var professoresModule = angular.module('professoresModule',[])

professoresModule.controller('professoresController', function($scope){
    $scope.professores = [
        {codigo: 1,
         nome: 'Roberto Melo',
         email: 'robertoreboucasdemelo@gmail.com',
         telefone: '011 98453-7373'
        },
        {codigo: 2,
            nome: 'Marcelo Ferrari',
            email: 'celo_ferrari@gmail.com',
            telefone: '011 87456-2435'
        },
        {codigo: 3,
            nome: 'Liza Ferrari',
            email: 'ferrari_liza@gmail.com',
            telefone: '011 99090-0450'
        },
        {codigo: 4,
            nome: 'Alex Pereira',
            email: 'alex_pereira@gmail.com',
            telefone: '021 99456-7860'
        }
    ];


    $scope.selecionaProfessor = function(professorSelecionado){
        $scope.professor = professorSelecionado;
    }

    $scope.novo = function(){
        $scope.professor = null;
    }

    $scope.gravar = function(){
        $scope.professores.push($scope.professor);
        $scope.novo();
    }

    $scope.excluir = function(){
        $scope.professores.splice($scope.professores.indexOf($scope.professor),1);
        $scope.novo();
    }
});